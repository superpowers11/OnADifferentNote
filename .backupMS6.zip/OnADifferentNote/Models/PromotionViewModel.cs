﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnADifferentNote.Models
{
    public class PromotionViewModel
    {
        public string PromotionName { get; set; }
        public double SalePrice { get; set; }
    }
}