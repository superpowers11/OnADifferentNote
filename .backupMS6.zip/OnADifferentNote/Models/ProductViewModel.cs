﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnADifferentNote.Models
{
    public class ProductViewModel
    {
        public string ProductName { get; set; }
        public double ProductPrice { get; set; }
        public string ProductImageUrl { get; set; }
        public bool isFeaturedProduct { get; set; }
        public double ProductSalePrice { get; set; }
    }
}