﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnADifferentNote.Models
{
    public class HomeIndexViewModel : BaseViewModel //colon means "inherits" here
    {
    }
}