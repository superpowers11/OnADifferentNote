﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnADifferentNote.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private IRepository<Product> _productRepository;
        private IRepository<Promotion> _promoRepository;
        private IRepository<User> _userRepository;

        private OnADifferentNoteDbEntities _context;

        public UnitOfWork()
        {
            _context = new OnADifferentNoteDbEntities();
        }

        public IRepository<Product> ProductRepository
        {
            get { return _productRepository ?? (_productRepository = new GenericRepository<Product>(_context)); }
            //set method not needed
        }
        public IRepository<Promotion> PromoRepository
        {
            get { return _promoRepository ?? (_promoRepository = new GenericRepository<Promotion>(_context)); }
        }


        public IRepository<User> UserRepository
        {
            get { return _userRepository ?? (_userRepository = new GenericRepository<User>(_context)); }
        }
        public bool Save()
        { 
            _context.SaveChanges();
            return true;
        }

    }
}