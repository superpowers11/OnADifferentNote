﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnADifferentNote.Services;
using OnADifferentNote.Models;
using OnADifferentNote.Repositories;

namespace OnADifferentNote.Controllers
{
    public class HomeController : Controller
    {
        private IProductService _productService;
        private IPromoService _promoService;

        public HomeController()
        {
            var unitOfWork = new UnitOfWork();
            _productService = new ProductService(unitOfWork);
            _promoService = new PromoService(unitOfWork);
        }

        public HomeController(IProductService productService, IPromoService promoService)
        {
            _productService = productService;
            _promoService = promoService;
        }

        public ActionResult Index()
        {
            HomeIndexViewModel viewModel = new HomeIndexViewModel();
            Product featuredProduct = _productService.GetFeaturedProduct();
            if (featuredProduct == null)
            {
                return View(viewModel);
            }
            else
            {
                ProductViewModel productViewModel = GetProductViewModel(featuredProduct);
                productViewModel.isFeaturedProduct = true;
                viewModel.FeaturedProduct = productViewModel;
                return View(viewModel);
            }
        }
        private ProductViewModel GetProductViewModel(Product product)
        { 
            ProductViewModel productViewModel = new ProductViewModel();
            productViewModel.ProductName = product.ProductName;
            productViewModel.ProductPrice = product.Price;
            productViewModel.ProductImageUrl = product.ProductImageUrl;
            int productId = product.ProductId;
            string zipString = Response.Cookies.Get("Zip Code Cookie").Value;
            int zipCode;
            bool parsed = int.TryParse(zipString, out zipCode);
            Promotion productPromotion = _promoService.GetPromoByProduct(productId, zipCode);
            if (productPromotion != null)
            {
                double? nullablePrice = productPromotion.SalePrice;
                if (nullablePrice.HasValue)
                {
                    productViewModel.ProductSalePrice = nullablePrice.Value;
                    return productViewModel;
                }
                return productViewModel;
            }
            else
            {
                return productViewModel;
            }
        }
        public string UpdateZip(string zipCode)
        {
            // Create cookie
            HttpCookie ZipCodeCookie = new HttpCookie("Zip Code Cookie");
            //Add zip code value to cookie
            ZipCodeCookie.Value = zipCode;
            // Call SetCookie on Response obj
            Response.SetCookie(ZipCodeCookie);

            return "it worked";
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}