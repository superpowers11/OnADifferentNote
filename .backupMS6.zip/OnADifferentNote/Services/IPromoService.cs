﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnADifferentNote.Services
{
    public interface IPromoService
    {
        Promotion GetPromoByProduct(int productId, int zipCode);
    }
}