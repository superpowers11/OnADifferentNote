﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OnADifferentNote.Repositories;

namespace OnADifferentNote.Services
{
    public class UserService :IUserService
    {
        private IUnitOfWork _unitOfWork;

        public UserService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        //public User CreateUser(string firstName, string lastName, string email)
        //{

        //}
    }
}