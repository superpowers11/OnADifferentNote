﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnADifferentNote.Services
{
    public interface IUserService
    {
        //User CreateUser(string firstName = "No First Name", string lastName = "No Last Name", string email = "default@none.org");
    }
}
