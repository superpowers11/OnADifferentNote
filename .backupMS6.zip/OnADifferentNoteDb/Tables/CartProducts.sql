﻿CREATE TABLE [dbo].[CartProducts]
(
	[Id] INT NOT NULL PRIMARY KEY
)
