﻿$(document).ready(function(){
    var zipButton = document.getElementById("zipCodeButton");


    function  zipUpdate() {
        var data = { zipCode: $("#zipCode").val() };
        $.ajax(
            {
                url: "/Home/UpdateZip",
              
                data: JSON.stringify(data),
                type: "POST",
              
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    alert(data)
                },
                error: function () {
                    alert("Error");
                }
            })
    }
    zipButton.addEventListener("click", function () {zipUpdate();}, false)
});



    //$("#zipCodeButton").on("click", function () {
    //    var data = {
    //        zipCode: $("#zipCode").val()
            
    //    }
    //    $.ajax({
    //            url: "/home/UpdateZip",
    //            data: data,
    //            type: "POST",
    //            dataType: "json",
    //            success: function (json) {
    //               alert("Successfully updated!");
    //            }
    //        })
    //})
